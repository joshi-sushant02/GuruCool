from django.apps import AppConfig


class ClassroomConfig(AppConfig):
    name = 'classroom'
