from django.apps import AppConfig


class OpenformsConfig(AppConfig):
    name = 'openforms'
